<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Ucapan::index');
$routes->get('/register', 'Home::register');
// $routes->get('/dashboard', 'Home::dashboard');
$routes->get('/dashboard', 'Ucapan::index');
$routes->get('/invitation', 'Invitation::invitation');
$routes->get('/invitation/data', 'Ucapan::display');
$routes->post('/invitation/insert', 'Ucapan::insert');
$routes->get('/invitation/(:num)', 'Ucapan::idUndangan/$1');
$routes->get('test_form', function () {
    return view('test_form');
});

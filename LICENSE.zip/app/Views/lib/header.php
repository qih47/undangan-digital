<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CI4Project</title>
    <link rel="shortcut icon" type="image/png" href="<?= base_url(); ?>/images/logos/favicon.png" />
    <link rel="stylesheet" href="<?= base_url(); ?>/css/styles.min.css" />
</head>
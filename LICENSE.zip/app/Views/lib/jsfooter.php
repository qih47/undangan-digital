  <script src="<?= base_url(); ?>/libs/jquery/dist/jquery.min.js"></script>
  <script src="<?= base_url(); ?>/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url(); ?>/js/sidebarmenu.js"></script>
  <script src="<?= base_url(); ?>/js/app.min.js"></script>
  <script src="<?= base_url(); ?>/libs/simplebar/dist/simplebar.js"></script>
  <!-- solar icons -->
  <script src="https://cdn.jsdelivr.net/npm/iconify-icon@1.0.8/dist/iconify-icon.min.js"></script>
<?php

namespace App\Controllers;

class Invitation extends BaseController
{
    public function invitation(): string
    {
        return view('invitation/index');
    }
}
